#ifndef __USB_HAL_H__
#define __USB_HAL_H__


void rtl8192cu_set_hal_ops(_adapter * padapter);

void rtl8192du_set_hal_ops(_adapter * padapter);

#endif //__USB_HAL_H__

