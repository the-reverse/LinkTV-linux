#ifndef __USB_OPS_H_
#define __USB_OPS_H_

#include <drv_conf.h>
#include <osdep_service.h>
#include <drv_types.h>
#include <osdep_intf.h>

#define REALTEK_USB_VENQT_READ		0xC0
#define REALTEK_USB_VENQT_WRITE		0x40
#define REALTEK_USB_VENQT_CMD_REQ	0x05
#define REALTEK_USB_VENQT_CMD_IDX	0x00

enum{
	VENDOR_WRITE = 0x00,
	VENDOR_READ = 0x01,
};


#ifdef CONFIG_RTL8192C
void rtl8192cu_set_intf_ops(struct _io_ops *pops);

void rtl8192cu_recv_tasklet(void *priv);

void rtl8192cu_xmit_tasklet(void *priv);
#endif
#ifdef CONFIG_RTL8192D
void rtl8192du_set_intf_ops(struct _io_ops *pops);

void rtl8192du_recv_tasklet(void *priv);

void rtl8192du_xmit_tasklet(void *priv);
#endif

#endif
